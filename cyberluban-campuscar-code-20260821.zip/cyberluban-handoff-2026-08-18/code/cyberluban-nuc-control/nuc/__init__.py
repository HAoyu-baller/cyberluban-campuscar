"""CyberLubban NUC controller package."""
