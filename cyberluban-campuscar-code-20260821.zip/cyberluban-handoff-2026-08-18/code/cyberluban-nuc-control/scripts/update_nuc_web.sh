#!/usr/bin/env bash
set -euo pipefail

if [[ "${EUID}" -ne 0 ]]; then
  echo "Please run: sudo ./scripts/update_nuc_web.sh"
  exit 1
fi

SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
INSTALL_DIR="/opt/cyberluban-control"

if [[ ! -x "${INSTALL_DIR}/.venv/bin/python" ]]; then
  echo "Existing installation not found at ${INSTALL_DIR}."
  echo "Run sudo ./scripts/install_nuc.sh instead."
  exit 1
fi

"${INSTALL_DIR}/.venv/bin/python" -c "import fastapi, serial, uvicorn, websockets"

install -d -m 0755 "${INSTALL_DIR}/nuc/static"
install -m 0644 "${SOURCE_DIR}/nuc/__init__.py" "${INSTALL_DIR}/nuc/__init__.py"
install -m 0644 "${SOURCE_DIR}/nuc/app.py" "${INSTALL_DIR}/nuc/app.py"
install -m 0644 "${SOURCE_DIR}/nuc/serial_bridge.py" "${INSTALL_DIR}/nuc/serial_bridge.py"
install -m 0644 "${SOURCE_DIR}/nuc/settings.py" "${INSTALL_DIR}/nuc/settings.py"
install -m 0644 "${SOURCE_DIR}/nuc/static/index.html" "${INSTALL_DIR}/nuc/static/index.html"
install -m 0644 "${SOURCE_DIR}/nuc/static/app.js" "${INSTALL_DIR}/nuc/static/app.js"
install -m 0644 "${SOURCE_DIR}/nuc/static/style.css" "${INSTALL_DIR}/nuc/static/style.css"

"${INSTALL_DIR}/.venv/bin/python" -m compileall -q "${INSTALL_DIR}/nuc"
systemctl restart cyberluban-control.service
sleep 1
systemctl is-active --quiet cyberluban-control.service

echo "NUC web controller updated successfully."
echo "Your existing control token and /etc/cyberluban-control.env were preserved."
echo "Open http://NUC_IP:8000 and hard-refresh the browser with Ctrl+F5."
