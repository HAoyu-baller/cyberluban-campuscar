from __future__ import annotations

import queue
import re
import threading
import time
import tkinter as tk
from tkinter import messagebox, ttk

import serial
from serial.tools import list_ports


BAUD_RATE = 115200
BOOT_WAIT_MS = 2200
HEARTBEAT_INTERVAL_MS = 100
DRIVE_SEND_INTERVAL = 0.15
SPRAY_SEND_INTERVAL = 0.40
REQUIRED_PROTOCOL = 3

DIRECTION_NAMES = {
    "w": "前进",
    "s": "后退",
    "a": "左转",
    "d": "右转",
}


class SerialConnection:
    def __init__(self, event_queue: queue.Queue[tuple[str, str]]) -> None:
        self.event_queue = event_queue
        self.connection: serial.Serial | None = None
        self.write_lock = threading.Lock()
        self.stop_event = threading.Event()
        self.reader_thread: threading.Thread | None = None

    @property
    def connected(self) -> bool:
        return bool(self.connection and self.connection.is_open)

    def open(self, port: str) -> None:
        self.close()
        self.stop_event.clear()
        self.connection = serial.Serial(
            port=port,
            baudrate=BAUD_RATE,
            timeout=0.08,
            write_timeout=0.30,
        )
        self.reader_thread = threading.Thread(
            target=self._reader_loop,
            name="esp32-reader",
            daemon=True,
        )
        self.reader_thread.start()

    def send(self, command: str) -> None:
        if len(command) != 1:
            raise ValueError("ESP32 commands must be one character")
        connection = self.connection
        if not connection or not connection.is_open:
            raise serial.SerialException("串口未连接")
        with self.write_lock:
            connection.write(command.encode("ascii"))
            connection.flush()

    def clear_input(self) -> None:
        connection = self.connection
        if connection and connection.is_open:
            connection.reset_input_buffer()

    def close(self) -> None:
        self.stop_event.set()
        connection = self.connection
        if connection and connection.is_open:
            try:
                with self.write_lock:
                    connection.write(b"x")
                    connection.flush()
            except (serial.SerialException, OSError):
                pass
            try:
                connection.close()
            except (serial.SerialException, OSError):
                pass
        self.connection = None

    def _reader_loop(self) -> None:
        connection = self.connection
        if not connection:
            return
        try:
            while not self.stop_event.is_set() and connection.is_open:
                raw = connection.readline()
                if not raw:
                    continue
                line = raw.decode("utf-8", errors="replace").strip()
                if line:
                    self.event_queue.put(("line", line))
        except (serial.SerialException, OSError) as exc:
            if not self.stop_event.is_set():
                self.event_queue.put(("error", str(exc)))


class CarControllerApp:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.root.title("Cyber鲁班 · ESP32 电脑直连控制器")
        self.root.geometry("780x720")
        self.root.minsize(720, 650)

        self.events: queue.Queue[tuple[str, str]] = queue.Queue()
        self.serial_link = SerialConnection(self.events)
        self.port_map: dict[str, str] = {}
        self.ready_after_boot = False
        self.firmware_protocol: int | None = None
        self.firmware_ok = False
        self.held_directions: list[str] = []
        self.active_direction: str | None = None
        self.spray_on = False
        self.last_drive_send = 0.0
        self.last_spray_send = 0.0
        self.focus_check_job: str | None = None
        self.closing = False

        self.status_var = tk.StringVar(value="未连接")
        self.firmware_var = tk.StringVar(value="固件：未检测")
        self.action_var = tk.StringVar(value="运动：停止　|　喷水：关闭")
        self.port_var = tk.StringVar()

        self._build_ui()
        self._bind_keys()
        self.refresh_ports()

        self.root.protocol("WM_DELETE_WINDOW", self.close_app)
        self.root.bind("<FocusOut>", self._schedule_focus_check, add="+")
        self.root.bind("<Unmap>", self._on_window_hidden, add="+")
        self.root.after(40, self._process_events)
        self.root.after(HEARTBEAT_INTERVAL_MS, self._heartbeat)

    def _build_ui(self) -> None:
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("Title.TLabel", font=("Microsoft YaHei UI", 20, "bold"))
        style.configure("Heading.TLabel", font=("Microsoft YaHei UI", 11, "bold"))
        style.configure("Status.TLabel", font=("Microsoft YaHei UI", 10))
        style.configure("Drive.TButton", font=("Microsoft YaHei UI", 15, "bold"), padding=16)
        style.configure("Action.TButton", font=("Microsoft YaHei UI", 10, "bold"), padding=10)
        style.configure("Stop.TButton", font=("Microsoft YaHei UI", 13, "bold"), padding=14)

        outer = ttk.Frame(self.root, padding=18)
        outer.pack(fill="both", expand=True)

        ttk.Label(outer, text="ESP32 电脑直连控制器", style="Title.TLabel").pack(anchor="w")
        ttk.Label(
            outer,
            text="按住 W / S / A / D 连续行进，松开立即停止；空格强制停止全部活动。",
        ).pack(anchor="w", pady=(4, 14))

        connection_frame = ttk.LabelFrame(outer, text="串口连接", padding=12)
        connection_frame.pack(fill="x")
        connection_frame.columnconfigure(1, weight=1)

        ttk.Label(connection_frame, text="ESP32 端口：").grid(row=0, column=0, sticky="w")
        self.port_box = ttk.Combobox(
            connection_frame,
            textvariable=self.port_var,
            state="readonly",
            width=48,
        )
        self.port_box.grid(row=0, column=1, sticky="ew", padx=8)
        ttk.Button(connection_frame, text="刷新", command=self.refresh_ports).grid(row=0, column=2)

        button_row = ttk.Frame(connection_frame)
        button_row.grid(row=1, column=0, columnspan=3, sticky="ew", pady=(10, 0))
        self.connect_button = ttk.Button(button_row, text="连接 ESP32", command=self.toggle_connection)
        self.connect_button.pack(side="left")
        ttk.Label(button_row, textvariable=self.status_var, style="Status.TLabel").pack(side="left", padx=14)
        ttk.Label(button_row, textvariable=self.firmware_var, style="Status.TLabel").pack(side="right")

        control_frame = ttk.LabelFrame(outer, text="运动控制", padding=14)
        control_frame.pack(fill="x", pady=12)
        for column in range(3):
            control_frame.columnconfigure(column, weight=1)

        self.direction_buttons: dict[str, ttk.Button] = {}
        positions = {
            "w": (0, 1, "W\n前进"),
            "a": (1, 0, "A\n左转"),
            "s": (1, 1, "S\n后退"),
            "d": (1, 2, "D\n右转"),
        }
        for command, (row, column, label) in positions.items():
            button = ttk.Button(control_frame, text=label, style="Drive.TButton")
            button.grid(row=row, column=column, sticky="nsew", padx=5, pady=5)
            button.bind("<ButtonPress-1>", lambda event, c=command: self._press_direction(c))
            button.bind("<ButtonRelease-1>", lambda event, c=command: self._release_direction(c))
            button.bind("<Leave>", lambda event, c=command: self._release_direction(c))
            self.direction_buttons[command] = button

        ttk.Label(control_frame, textvariable=self.action_var, style="Heading.TLabel").grid(
            row=2, column=0, columnspan=3, pady=(12, 2)
        )

        actions = ttk.LabelFrame(outer, text="功能与安全", padding=12)
        actions.pack(fill="x")
        for column in range(4):
            actions.columnconfigure(column, weight=1)

        ttk.Button(actions, text="G　请求校准", style="Action.TButton", command=self.request_activation).grid(
            row=0, column=0, sticky="ew", padx=4
        )
        ttk.Button(actions, text="K　开始喷水", style="Action.TButton", command=self.start_spray).grid(
            row=0, column=1, sticky="ew", padx=4
        )
        ttk.Button(actions, text="L　停止喷水", style="Action.TButton", command=self.stop_spray).grid(
            row=0, column=2, sticky="ew", padx=4
        )
        ttk.Button(actions, text="M　停止运动", style="Action.TButton", command=self.stop_movement).grid(
            row=0, column=3, sticky="ew", padx=4
        )
        ttk.Button(
            actions,
            text="空格　强制停止运动、喷水和待执行动作",
            style="Stop.TButton",
            command=lambda: self.emergency_stop("点击急停按钮"),
        ).grid(row=1, column=0, columnspan=4, sticky="ew", padx=4, pady=(10, 0))

        log_frame = ttk.LabelFrame(outer, text="ESP32 日志", padding=8)
        log_frame.pack(fill="both", expand=True, pady=(12, 0))
        self.log_text = tk.Text(
            log_frame,
            height=12,
            state="disabled",
            wrap="word",
            font=("Consolas", 9),
            background="#101510",
            foreground="#d8e8d8",
            insertbackground="white",
        )
        scrollbar = ttk.Scrollbar(log_frame, orient="vertical", command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=scrollbar.set)
        self.log_text.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

    def _bind_keys(self) -> None:
        self.root.bind_all("<KeyPress>", self._on_key_press, add="+")
        self.root.bind_all("<KeyRelease>", self._on_key_release, add="+")

    def refresh_ports(self) -> None:
        ports = sorted(list_ports.comports(), key=lambda item: item.device)
        self.port_map.clear()
        choices: list[str] = []
        for port in ports:
            description = port.description or "未知设备"
            label = f"{port.device} — {description}"
            self.port_map[label] = port.device
            choices.append(label)
        self.port_box["values"] = choices
        if choices:
            preferred = next(
                (
                    item
                    for item in choices
                    if any(word in item.lower() for word in ("cp210", "ch340", "esp32", "usb serial"))
                ),
                choices[0],
            )
            self.port_var.set(preferred)
        else:
            self.port_var.set("")
        self._log(f"发现 {len(choices)} 个串口。")

    def toggle_connection(self) -> None:
        if self.serial_link.connected:
            self.disconnect("用户断开")
            return
        selection = self.port_var.get()
        port = self.port_map.get(selection)
        if not port:
            messagebox.showwarning("未选择端口", "请插入 ESP32，点击刷新并选择对应 COM 端口。")
            return
        try:
            self.ready_after_boot = False
            self.firmware_protocol = None
            self.firmware_ok = False
            self._clear_control_state()
            self.serial_link.open(port)
        except (serial.SerialException, OSError) as exc:
            messagebox.showerror(
                "串口连接失败",
                f"无法打开 {port}：\n{exc}\n\n请关闭 Arduino IDE 串口监视器后重试。",
            )
            return
        self.status_var.set(f"已打开 {port}，等待 ESP32 重启…")
        self.firmware_var.set("固件：检测中")
        self.connect_button.configure(text="断开并急停")
        self.port_box.configure(state="disabled")
        self._log(f"已打开 {port}；等待 {BOOT_WAIT_MS / 1000:.1f} 秒后进行安全初始化。")
        self.root.after(BOOT_WAIT_MS, self._finish_connection)

    def _finish_connection(self) -> None:
        if not self.serial_link.connected:
            return
        try:
            self.serial_link.clear_input()
            self.serial_link.send("x")
            self.serial_link.send("h")
            self.ready_after_boot = True
            self.status_var.set("串口已连接；等待固件版本信息")
            self._log("TX: x（启动急停）")
            self._log("TX: h（读取固件版本）")
        except (serial.SerialException, OSError) as exc:
            self._serial_failure(str(exc))

    def disconnect(self, reason: str) -> None:
        self._clear_control_state()
        self.serial_link.close()
        self.ready_after_boot = False
        self.firmware_protocol = None
        self.firmware_ok = False
        self.status_var.set("未连接")
        self.firmware_var.set("固件：未检测")
        self.connect_button.configure(text="连接 ESP32")
        self.port_box.configure(state="readonly")
        self._log(f"已断开：{reason}；断开前已尝试发送急停。")

    def _safe_send(self, command: str, *, require_v3: bool = True) -> bool:
        if not self.serial_link.connected or not self.ready_after_boot:
            return False
        if require_v3 and not self.firmware_ok:
            self.status_var.set("禁止控制：需要 protocol 3 固件")
            return False
        try:
            self.serial_link.send(command)
            return True
        except (serial.SerialException, OSError) as exc:
            self._serial_failure(str(exc))
            return False

    def _press_direction(self, command: str) -> None:
        if not self.firmware_ok:
            return
        if command in self.held_directions:
            self.held_directions.remove(command)
        self.held_directions.append(command)
        self.active_direction = command
        if self._safe_send(command):
            self.last_drive_send = time.monotonic()
        self._update_action_text()

    def _release_direction(self, command: str) -> None:
        if command in self.held_directions:
            self.held_directions.remove(command)
        new_direction = self.held_directions[-1] if self.held_directions else None
        if new_direction == self.active_direction:
            return
        self.active_direction = new_direction
        if new_direction:
            if self._safe_send(new_direction):
                self.last_drive_send = time.monotonic()
        else:
            self._safe_send("m")
        self._update_action_text()

    def stop_movement(self) -> None:
        self.held_directions.clear()
        self.active_direction = None
        self._safe_send("m", require_v3=False)
        self._update_action_text()
        self._log("TX: m（停止运动）")

    def start_spray(self) -> None:
        if not self.firmware_ok:
            return
        self.spray_on = True
        if self._safe_send("k"):
            self.last_spray_send = time.monotonic()
            self._log("TX: k（开始喷水）")
        self._update_action_text()

    def stop_spray(self) -> None:
        self.spray_on = False
        self._safe_send("l", require_v3=False)
        self._update_action_text()
        self._log("TX: l（停止喷水）")

    def request_activation(self) -> None:
        if self._safe_send("g"):
            self._log("TX: g（请求校准/激活）")

    def emergency_stop(self, reason: str) -> None:
        self._clear_control_state()
        self._safe_send("x", require_v3=False)
        self._log(f"TX: x（强制急停：{reason}）")
        self.status_var.set(f"已急停：{reason}")

    def _clear_control_state(self) -> None:
        self.held_directions.clear()
        self.active_direction = None
        self.spray_on = False
        self.last_drive_send = 0.0
        self.last_spray_send = 0.0
        self._update_action_text()

    def _heartbeat(self) -> None:
        if self.closing:
            return
        now = time.monotonic()
        if self.firmware_ok and self.serial_link.connected:
            if self.active_direction and now - self.last_drive_send >= DRIVE_SEND_INTERVAL:
                if self._safe_send(self.active_direction):
                    self.last_drive_send = now
            if self.spray_on and now - self.last_spray_send >= SPRAY_SEND_INTERVAL:
                if self._safe_send("k"):
                    self.last_spray_send = now
        self.root.after(HEARTBEAT_INTERVAL_MS, self._heartbeat)

    def _on_key_press(self, event: tk.Event) -> str | None:
        key = str(event.keysym).lower()
        if key == "space":
            self.emergency_stop("空格键")
            return "break"
        if key in DIRECTION_NAMES:
            self._press_direction(key)
            return "break"
        if key == "k":
            self.start_spray()
            return "break"
        if key == "l":
            self.stop_spray()
            return "break"
        if key == "g":
            self.request_activation()
            return "break"
        if key == "m":
            self.stop_movement()
            return "break"
        if key == "escape":
            self.emergency_stop("Esc 键")
            return "break"
        return None

    def _on_key_release(self, event: tk.Event) -> str | None:
        key = str(event.keysym).lower()
        if key in DIRECTION_NAMES:
            self._release_direction(key)
            return "break"
        return None

    def _schedule_focus_check(self, _event: tk.Event) -> None:
        if self.focus_check_job:
            try:
                self.root.after_cancel(self.focus_check_job)
            except tk.TclError:
                pass
        self.focus_check_job = self.root.after(80, self._check_focus)

    def _check_focus(self) -> None:
        self.focus_check_job = None
        if self.closing:
            return
        if self.root.focus_displayof() is None and (
            self.active_direction or self.spray_on
        ):
            self.emergency_stop("控制窗口失去焦点")

    def _on_window_hidden(self, _event: tk.Event) -> None:
        if not self.closing and (self.active_direction or self.spray_on):
            self.emergency_stop("窗口最小化或隐藏")

    def _process_events(self) -> None:
        if self.closing:
            return
        while True:
            try:
                event_type, payload = self.events.get_nowait()
            except queue.Empty:
                break
            if event_type == "line":
                self._handle_serial_line(payload)
            elif event_type == "error":
                self._serial_failure(payload)
        self.root.after(40, self._process_events)

    def _handle_serial_line(self, line: str) -> None:
        self._log(f"ESP32: {line}")
        match = re.search(r"READY\s+protocol=(\d+)(?:\s+firmware=([^\s]+))?", line)
        if not match:
            return
        self.firmware_protocol = int(match.group(1))
        version = match.group(2) or "未标注"
        self.firmware_ok = self.firmware_protocol >= REQUIRED_PROTOCOL
        if self.firmware_ok:
            self.firmware_var.set(f"固件：protocol {self.firmware_protocol} / {version}")
            self.status_var.set("可控制：请先架空车轮并执行 G 校准")
            self._log("固件版本检查通过，运动控制已解锁。")
        else:
            self.firmware_var.set(f"旧固件：protocol {self.firmware_protocol}")
            self.status_var.set("禁止运动：请烧录 protocol 3 固件")
            self._safe_send("x", require_v3=False)
            self._log("安全锁定：当前固件低于 protocol 3，已发送急停。")

    def _serial_failure(self, error: str) -> None:
        if not self.serial_link.connected:
            return
        self._log(f"串口错误：{error}")
        self.disconnect("串口异常")
        messagebox.showerror("串口连接中断", f"ESP32 串口连接已中断：\n{error}\n\nESP32 心跳超时后会自动停车。")

    def _update_action_text(self) -> None:
        movement = DIRECTION_NAMES.get(self.active_direction or "", "停止")
        spray = "开启" if self.spray_on else "关闭"
        self.action_var.set(f"运动：{movement}　|　喷水：{spray}")

    def _log(self, message: str) -> None:
        timestamp = time.strftime("%H:%M:%S")
        self.log_text.configure(state="normal")
        self.log_text.insert("end", f"{timestamp}  {message}\n")
        self.log_text.see("end")
        self.log_text.configure(state="disabled")

    def close_app(self) -> None:
        if self.closing:
            return
        self.closing = True
        self._clear_control_state()
        self.serial_link.close()
        self.root.destroy()


def main() -> None:
    root = tk.Tk()
    app = CarControllerApp(root)
    try:
        root.mainloop()
    finally:
        if not app.closing:
            app.serial_link.close()


if __name__ == "__main__":
    main()
