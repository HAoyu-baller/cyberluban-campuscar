@echo off
setlocal
cd /d "%~dp0"

where py >nul 2>nul
if errorlevel 1 (
  echo Python launcher "py" was not found.
  echo Install Python 3 from https://www.python.org/ and enable "Add Python to PATH".
  pause
  exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
  echo Creating local Python environment...
  py -3 -m venv .venv
  if errorlevel 1 goto :failed
)

echo Installing/checking dependency...
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto :failed

".venv\Scripts\python.exe" pc_esp32_car_controller.py
exit /b %errorlevel%

:failed
echo.
echo Setup failed. Check the messages above and the Internet connection.
pause
exit /b 1
