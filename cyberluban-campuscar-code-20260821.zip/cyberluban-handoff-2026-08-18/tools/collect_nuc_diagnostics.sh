#!/usr/bin/env bash
# Read-only diagnostic collector for the CyberLubban NUC.
# It does not modify services, networking, serial devices, or configuration.

set -u

section() {
  echo
  echo "===== $1 ====="
}

run_readonly() {
  "$@" 2>&1 || true
}

section "collection time"
run_readonly date -Is

section "identity and OS"
run_readonly hostname
run_readonly whoami
run_readonly uname -a
run_readonly bash -c 'test -r /etc/os-release && cat /etc/os-release'

section "network addresses"
run_readonly hostname -I
if command -v ip >/dev/null 2>&1; then
  run_readonly ip -brief address
  run_readonly ip route
fi

section "NetworkManager"
if command -v nmcli >/dev/null 2>&1; then
  run_readonly nmcli -f NAME,TYPE,DEVICE connection show --active
  run_readonly nmcli -f GENERAL.STATE,GENERAL.CONNECTION device show
else
  echo "nmcli not installed"
fi

section "service state"
run_readonly systemctl is-enabled cyberluban-control.service
run_readonly systemctl is-active cyberluban-control.service
run_readonly systemctl status cyberluban-control.service --no-pager

section "safe environment fields"
if [[ -r /etc/cyberluban-control.env ]]; then
  awk -F= '
    /^CONTROL_TOKEN=/ {print "CONTROL_TOKEN=<redacted>"; next}
    /^(SERIAL_|WEB_|CLIENT_|DRIVE_|SPRAY_)/ {print}
  ' /etc/cyberluban-control.env
else
  echo "/etc/cyberluban-control.env is not readable by current user"
  echo "Run this script with sudo only if the team accepts root-level diagnostics."
fi

section "serial devices"
run_readonly bash -c 'ls -l /dev/ttyUSB* /dev/ttyACM* 2>/dev/null'
if [[ -x /opt/cyberluban-control/.venv/bin/python ]] &&
   [[ -f /opt/cyberluban-control/scripts/find_serial.py ]]; then
  run_readonly /opt/cyberluban-control/.venv/bin/python \
    /opt/cyberluban-control/scripts/find_serial.py
fi

section "local web health"
if command -v curl >/dev/null 2>&1; then
  run_readonly curl --max-time 3 -sS http://127.0.0.1:8000/health
  echo
  run_readonly bash -c \
    'curl --max-time 3 -sS http://127.0.0.1:8000/ | grep -o "WEB V[0-9][0-9]*" | head -n 1'
else
  echo "curl not installed"
fi

section "listening port"
if command -v ss >/dev/null 2>&1; then
  run_readonly bash -c "ss -ltnp | grep ':8000'"
fi

section "recent service log"
run_readonly journalctl -u cyberluban-control.service -n 100 --no-pager

section "installed source markers"
run_readonly bash -c \
  'grep -n "message_type == \"activate\"" /opt/cyberluban-control/nuc/app.py'
run_readonly bash -c \
  'grep -n "websockets" /opt/cyberluban-control/requirements.txt'

echo
echo "Diagnostics complete. CONTROL_TOKEN was not printed."
