#!/usr/bin/env bash
# Safe release check. No files, services, or settings are modified.

set -u
failures=0

pass() {
  echo "[PASS] $1"
}

fail() {
  echo "[FAIL] $1"
  failures=$((failures + 1))
}

if systemctl is-enabled --quiet cyberluban-control.service; then
  pass "cyberluban-control is enabled at boot"
else
  fail "cyberluban-control is not enabled at boot"
fi

if systemctl is-active --quiet cyberluban-control.service; then
  pass "cyberluban-control is active"
else
  fail "cyberluban-control is not active"
fi

health="$(curl --max-time 3 -sS http://127.0.0.1:8000/health 2>/dev/null || true)"
if [[ "${health}" == *'"ok":true'* ]]; then
  pass "/health reports ok=true"
else
  fail "/health did not report ok=true"
fi

if [[ "${health}" == *'"connected":true'* ]]; then
  pass "serial bridge reports connected=true"
else
  fail "serial bridge does not report connected=true"
fi

home_page="$(curl --max-time 3 -sS http://127.0.0.1:8000/ 2>/dev/null || true)"
if [[ "${home_page}" == *"WEB V4"* ]]; then
  pass "installed page contains WEB V4"
else
  fail "installed page does not contain WEB V4"
fi

if [[ -f /opt/cyberluban-control/nuc/app.py ]] &&
   grep -q 'message_type == "activate"' /opt/cyberluban-control/nuc/app.py; then
  pass "backend contains activate handler"
else
  fail "backend activate handler not found"
fi

if [[ -x /opt/cyberluban-control/.venv/bin/python ]] &&
   /opt/cyberluban-control/.venv/bin/python -c \
     'import fastapi, serial, uvicorn, websockets' >/dev/null 2>&1; then
  pass "required Python modules import successfully"
else
  fail "one or more Python modules cannot be imported"
fi

echo
echo "Manual firmware check is still required:"
echo "  stop the service, run scripts/serial_smoke_test.py, and require"
echo "  READY protocol=3 firmware=3.0-last-activity-timer baud=115200"

if (( failures > 0 )); then
  echo
  echo "Release check failed in ${failures} item(s)."
  exit 1
fi

echo
echo "NUC-side release checks passed."
